<?php
include"lib/conn.php";
print"<pre>";
print_r($_POST);
//$res = mysql_query($sql) or die();

?>
