<?php
$conn = mysqli_connect("localhost", "asif", "asif", "mobile_store");
if (!$conn) {
    die("connection error");
}
