<table width="100%" height="100%" border="1">
  <tr>
    <td height="10%" colspan="2"><h1>Welcome admin hi</h1></td>
  </tr>